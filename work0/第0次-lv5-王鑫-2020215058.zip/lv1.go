package main

import "fmt"
func main() {
a:=0
b:=0

fmt.Scan(&a,&b)

fmt.Print(a+b)
}
